# 灵策智算 · 抖音信息流广告落地页

## 本地部署

直接用任意静态服务器打开 `index.html` 即可。

### 方法一：Python（无依赖）
```bash
cd lingce-landing
python3 -m http.server 8080
# 浏览器访问 http://localhost:8080
```

### 方法二：Node http-server
```bash
npx http-server lingce-landing -p 8080
```

### 方法三：直接打开
双击 `index.html`（部分浏览器对本地资源有限制，推荐用上面的服务器方式）。

## 推荐预览方式
打开 Chrome DevTools，切换到移动端模拟器（iPhone 12 / 375×812）查看效果。

## 文件说明
- `index.html` — 落地页主结构
- `styles.css` — 样式（移动端 480px 居中布局）
- `script.js` — 轮播、表单校验、Toast、悬浮 CTA
- `assets/img/` — 顶部 2 张轮播图 + 中部 2 张长图海报

## 接入抖音/巨量引擎转化
在 `script.js` 中预留了 `window._tt_ad_track('form_submit', { position })` 钩子，
对接前请在页面引入抖音转化 SDK 并实现该方法。
